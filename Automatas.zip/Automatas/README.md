```bash
   ▄████████ ███    █▄      ███      ▄██████▄    ▄▄▄▄███▄▄▄▄      ▄████████     ███        ▄████████    ▄████████ 
  ███    ███ ███    ███ ▀█████████▄ ███    ███ ▄██▀▀▀███▀▀▀██▄   ███    ███ ▀█████████▄   ███    ███   ███    ███ 
  ███    ███ ███    ███    ▀███▀▀██ ███    ███ ███   ███   ███   ███    ███    ▀███▀▀██   ███    ███   ███    █▀  
  ███    ███ ███    ███     ███   ▀ ███    ███ ███   ███   ███   ███    ███     ███   ▀   ███    ███   ███        
▀███████████ ███    ███     ███     ███    ███ ███   ███   ███ ▀███████████     ███     ▀███████████ ▀███████████ 
  ███    ███ ███    ███     ███     ███    ███ ███   ███   ███   ███    ███     ███       ███    ███          ███ 
  ███    ███ ███    ███     ███     ███    ███ ███   ███   ███   ███    ███     ███       ███    ███    ▄█    ███ 
  ███    █▀  ████████▀     ▄████▀    ▀██████▀   ▀█   ███   █▀    ███    █▀     ▄████▀     ███    █▀   ▄████████▀  
                                                                                                                  
```
## Introduction
Esta es una aplicacion web diseñada para el ramo 'Lenguajes y Grafos Formales'<br>

## Uso
### Primero ingresar el alfabeto
<img src="img/paso1.png" height="300px">

### Seguido ingresamos la cantidad de estados del automata y su tipo
<img src="img/paso2.png" height="300px">

### Ingresamos las etiquetas
<img src="img/paso3.png" height="300px">

### Ahora podemos ver las operaciones
<img src="img/paso4.png" height="300px">

<!--
Todo
+ transition acordeon menu when open
-->
